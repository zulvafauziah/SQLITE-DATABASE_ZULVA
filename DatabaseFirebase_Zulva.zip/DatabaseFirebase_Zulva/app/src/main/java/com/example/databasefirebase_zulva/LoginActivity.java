package com.example.databasefirebase_zulva;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private TextView reg;
    private TextView forget;
    private EditText inputEmail , inputPassword;
    private ProgressDialog progressDialog;
    private Button btnlogin;
    private FirebaseAuth mAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        reg = (TextView) findViewById(R.id.tvsignup);
        forget = (TextView) findViewById(R.id.lupapassword);
        inputEmail = findViewById(R.id.et_emaillog);
        inputPassword = findViewById(R.id.et_passwordlog);
        btnlogin = findViewById(R.id.btn_log);

        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Please wait");
        progressDialog.setCancelable(false);

        //pindah ke halaman registrasi
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
            }
        });

        //pindah ke halaman lupa password
        forget.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), LupaPasswordActivity.class));
        });

        btnlogin.setOnClickListener(v -> {
            if (inputEmail.getText().length() > 0 && inputPassword.getText().length() > 0) {
                login(inputEmail.getText().toString(), inputPassword.getText().toString());
            } else {
                Toast.makeText(getApplicationContext(), "Please fill all data!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void login(String email, String password){
        //Codingan Login
        progressDialog.show();
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful() && task.getResult()!=null){
                    if (task.getResult().getUser()!=null){
                        startActivity(new Intent(getApplicationContext(), BerandaActivity.class));
                    }else{
                        Toast.makeText(getApplicationContext(), "Login failed", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "Login failed", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }
        });
    }
}{
}
