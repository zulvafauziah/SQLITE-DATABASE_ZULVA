package com.example.databasefirebase_zulva;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class BerandaActivity extends AppCompatActivity {
    ImageView profil,mnotif;
    FloatingActionButton tambah;
    private TextView tvNamapasien, tvNoantrian;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        tvNamapasien = findViewById(R.id.tv_namapasien);
        tvNoantrian = findViewById(R.id.tv_noantrrian);

        profil = findViewById(R.id.ivprofil);
        profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BerandaActivity.this, ProfilActivity.class));
            }
        });

        mnotif = findViewById(R.id.notif);
        mnotif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BerandaActivity.this, NotifikasiActivity.class));
            }
        });

        tambah = findViewById(R.id.btn_tambah);
        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BerandaActivity.this, PendaftaranUmumActivity.class));
            }
        });

    }
}{
}
