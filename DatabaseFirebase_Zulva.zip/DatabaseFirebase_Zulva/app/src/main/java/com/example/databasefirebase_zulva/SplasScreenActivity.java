package com.example.databasefirebase_zulva;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SplasScreenActivity extends AppCompatActivity {
    private ProgressBar progressBar;
    private Integer value = 0;
    private long pressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splas_screen);

        progressBar = (ProgressBar) findViewById(R.id.progressBar2);
        progressBar.setProgress(value);

        @SuppressLint("HandlerLeak")
        final Handler handler = new Handler() {
            @SuppressLint("SetTextI18n")
            @Override
            public void handleMessage(@NonNull Message msg){
                super.handleMessage(msg);

                if (value == progressBar.getMax()){
                    Intent intent = new Intent(SplasScreenActivity.this, LoginActivity.class);
                    startActivity(intent); SplasScreenActivity.this.finish();
                }value++;
            }


        };

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int prg=0; prg <= progressBar.getMax(); prg++) {
                        progressBar.setProgress(prg);
                        // Kirim pesan dari handler
                        handler.sendMessage(handler.obtainMessage());
                        if (prg > 78 && prg < 88) {
                            // Delay 10 milidetik
                            Thread.sleep(10);
                        } else if (prg == 99) {
                            // Delay 1500 milidetik
                            Thread.sleep(1500);
                        } else {
                            // Delay 50 milidetik
                            Thread.sleep(50);
                        }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }); thread.start();
    }

    @Override
    public void onBackPressed() {
        if (pressedTime+1500 > System.currentTimeMillis()) {
            super.onBackPressed(); System.exit(0);
        } else {
            Toast.makeText(SplasScreenActivity.this, "Tekan lagi untuk keluar", Toast.LENGTH_SHORT).show();
        } pressedTime = System.currentTimeMillis();
    }
}


